---
name: 新蝙蝠侠 The Batman
cover: https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2868425292.webp
tags: 剧情
douban_url: https://movie.douban.com/subject/6424756/
director: '马特·里夫斯'
rating: 7.6
year: 2022-03-18(中国大陆)
genre: 剧情
banner_icon: 🎞
banner: "https://img2.doubanio.com/view/photo/1/public/p2868425292.webp"
status: 想看
progress: 
banner_y: 0.244
---

[[震撼我的电影|电影清单]]

---

# 新蝙蝠侠 The Batman

**[2022-03-18(中国大陆)] | [ 175分钟 ]** 

布鲁斯·韦恩（罗伯特·帕丁森 饰）化身蝙蝠侠于哥谭市行侠仗义两年后，罪犯皆闻风丧胆，他也因此深入接触到哥谭市的阴暗面。他潜行于哥谭市腐败的政要名流关系网中，身边仅有的几个值得信赖的盟友——管家阿尔弗雷德·潘尼沃斯（安迪·瑟金斯 饰）与詹姆斯·戈登警长（杰弗里·怀特 饰）。这位独行的“义警侠探”在哥谭市民心中已成为“复仇”二字最当仁不让的代名词。

## 观后感

