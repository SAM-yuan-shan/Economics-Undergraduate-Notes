---
name: 阿凡达 Avatar
cover: https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2634997853.webp
tags: 动作
douban_url: https://movie.douban.com/subject/1652587/
director: '詹姆斯·卡梅隆'
rating: 8.8
year: 2010-01-04(中国大陆)
genre: 动作
banner_icon: 🎞
banner: "https://img2.doubanio.com/view/photo/1/public/p2634997853.webp"
status: 再看
progress: 
banner_y: 0.12
---

# 阿凡达 Avatar

**[2010-01-04(中国大陆)] | [ 162分钟 ]** 

战斗中负伤而下身瘫痪的前海军战士杰克·萨利（萨姆·沃辛顿 Sam Worthington 饰）决定替死去的同胞哥哥来到潘多拉星操纵格蕾丝博士（西格妮·韦弗 Sigourney Weaver 饰）用人类基因与当地纳美部族基因结合创造出的 “阿凡达” 混血生物。杰克的目的是打入纳美部落，外交说服他们自愿离开世代居住的家园，从而SecFor公司可砍伐殆尽该地区的原始森林，开采地下昂贵的“不可得”矿。在探索潘多拉星的过程中，杰克遇到了纳美部落的公主娜蒂瑞（佐伊·索尔达娜 Zoe Saldana 饰），向她学习了纳美人的生存技能与对待自然的态度。与此同时，SecFor公司的经理和军方代表上校迈尔斯（史蒂芬·朗 Stephen Lang 饰）逐渐丧失耐心，决定诉诸武力驱赶纳美人……



















本片采用3D技术拍摄，共耗资5亿美元制作发行，是电影史上最为昂贵的作品。本片荣获...

## 观后感

