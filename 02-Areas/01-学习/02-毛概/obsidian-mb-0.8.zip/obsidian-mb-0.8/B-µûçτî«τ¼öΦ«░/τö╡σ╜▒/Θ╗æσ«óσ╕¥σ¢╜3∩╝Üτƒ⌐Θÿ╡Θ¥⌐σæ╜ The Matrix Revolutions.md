---
name: 黑客帝国3：矩阵革命 The Matrix Revolutions
cover: https://img1.doubanio.com/view/photo/s_ratio_poster/public/p443461818.webp
tags: 动作
douban_url: https://movie.douban.com/subject/1302467/
director: '拉娜·沃卓斯基'
rating: 8.8
year: 2003-11-05(美国/中国大陆)
genre: 动作
banner_icon: 🎞
banner: "https://img1.doubanio.com/view/photo/1/public/p443461818.webp"
status: 再看
progress: 
banner_y: 0.276
---

[[震撼我的电影|电影清单]]

---

# 黑客帝国3：矩阵革命 The Matrix Revolutions

**[2003-11-05(美国/中国大陆)] | [ 129 分钟 ]** 

第二集中，尼奥（基努·里维斯 Keanu Reeves 饰）没有能从内部摧毁“母体”，他的身体在真实世界的飞船上陷于昏迷，思想却被困在介于“母体”和真实世界的中间地带，这个地方由“火车人”控制。墨菲斯（劳伦斯·菲什伯恩 Laurence Fishburne 饰）和崔妮蒂（凯瑞-安·莫斯 Carrie-Anne Moss 饰）等人知道了尼奥的情况，在守护天使的带领下， 找到了“火车人”的控制者梅罗纹奇，经过一番激斗，将尼奥救了出来。



















此时，电子乌贼部队对锡安发起了猛烈的攻击，人类组织所有机甲战士展开顽强的抵抗，形势危在旦夕；尼奥和崔妮蒂驾驶了一艘飞船克服重重困难，到达机器城市，尼奥终于见到了机器世界的统治者“机器大帝”，双方谈判并达成了协议：尼奥除掉不受“母体”控制的史密斯，以换取锡安的和平。



















在“母体”中，尼奥和史密斯展开了关系人类生死存亡的最后决斗...

## 观后感

