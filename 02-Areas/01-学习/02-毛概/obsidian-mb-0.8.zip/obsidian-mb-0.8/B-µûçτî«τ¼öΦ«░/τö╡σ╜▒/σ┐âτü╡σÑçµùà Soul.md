---
name: 心灵奇旅 Soul
cover: https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2626308994.webp
tags: 动画
douban_url: https://movie.douban.com/subject/24733428/
director: '彼特·道格特'
rating: 8.7
year: 2020-12-25(中国大陆/美国网络)
genre: 动画
banner_icon: 🎞
banner: "https://img9.doubanio.com/view/photo/1/public/p2626308994.webp"
status: 想看
progress: 
banner_y: 0.228
---

[[震撼我的电影|电影清单]]

---

# 心灵奇旅 Soul

**[2020-12-25(中国大陆/美国网络)] | [ 101分钟 ]** 

究竟是什么塑造了真正的你？电影将聚焦乔伊·高纳（杰米·福克斯配音）。这位中学音乐老师获得了梦寐以求的机会——在纽约最好的爵士俱乐部演奏。但一个小失误把他从纽约的街道带到了一个奇幻的地方“生之来处”（the Great Before）。在那里，灵魂们获得培训，在前往地球之前将获得他们的个性特点和兴趣。决心要回到地球生活的乔伊认识了一个早熟的灵魂“二十二”（蒂娜·菲 配音），二十二一直找不到自己对于人类生活的兴趣。随着乔伊不断试图向二十二展示生命的精彩之处，他也将领悟一些人生终极问题的答案。

## 观后感

