---
name: 钢铁侠3 Iron Man 3
cover: https://img2.doubanio.com/view/photo/s_ratio_poster/public/p1955027201.webp
tags: 动作
douban_url: https://movie.douban.com/subject/3231742/
director: '沙恩·布莱克'
rating: 7.8
year: 2013-05-01(中国大陆)
genre: 动作
banner_icon: 🎞
banner: "https://img2.doubanio.com/view/photo/1/public/p1955027201.webp"
status: 再看
progress: 
banner_y: 0.2
---

[[震撼我的电影|电影清单]]

---

# 钢铁侠3 Iron Man 3

**[2013-05-01(中国大陆)] | [ 134分钟(中国大陆) ]** 

自纽约事件以来，托尼·斯塔克（小罗伯特·唐尼 Robert Downey Jr. 饰）为前所未有的焦虑症所困扰。他疯狂投入钢铁侠升级版的研发，为此废寝忘食，甚至忽略了女友佩珀·波茨（格温妮斯·帕特洛 Gwyneth Paltrow 饰）的感受。与此同时，臭名昭著的恐怖头目曼达林（本·金斯利 Ben Kingsley 饰）制造了一连串的爆炸袭击事件，托尼当年最忠诚的保镖即在最近的一次袭击中身负重伤。未过多久，托尼、佩珀以及曾与他有过一面之缘的女植物学家玛雅（丽贝卡·豪尔 Rebecca Hall 饰）在家中遭到猛烈的炮火袭击，几乎丧命，而这一切似乎都与22年前那名偶然邂逅的科学家阿尔德里奇·基连（盖·皮尔斯 Guy Pearce 饰）及其终极生物的研究有关。



















即使有精密先进的铠甲护身，也无法排遣发自心底的焦虑。被击碎一切的托尼，如何穿越来自地狱的熊熊烈...

## 观后感

