---
name: 玩具总动员4 Toy Story 4
cover: https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2557284230.webp
tags: 喜剧
douban_url: https://movie.douban.com/subject/6850547/
director: '乔什·库雷'
rating: 8.5
year: 2019-06-21(美国/中国大陆)
genre: 喜剧
banner_icon: 🎞
banner: "https://img3.doubanio.com/view/photo/1/public/p2557284230.webp"
status: 再看
progress: 
banner_y: 0.46
---

[[震撼我的电影|电影清单]]

---

# 玩具总动员4 Toy Story 4

**[2019-06-21(美国/中国大陆)] | [ 100分钟 ]** 

胡迪深知自己在这个世界上的使命，就是照顾他的主人，无论是原来的安迪还是新主人邦妮。当邦妮将不情愿成为玩具的“叉叉”带回家时，胡迪又担起了教导叉叉接受自己新身份的责任。 然而当邦妮将所有玩具带上房车家庭旅行时，胡迪与伙伴们将共同踏上全新的冒险之旅，领略房间外面的世界有多广阔，甚至偶遇老朋友牧羊女。在多年的独自闯荡中，牧羊女已经变得热爱冒险，不再只是一个精致的洋娃娃。正当胡迪和牧羊女发现彼此对玩具的使命的意义大相径庭时，他们很快意识到更大的威胁即将到来……

## 观后感

