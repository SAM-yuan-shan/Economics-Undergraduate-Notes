---
name: 头脑特工队 Inside Out
cover: https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2266293606.webp
tags: 喜剧
douban_url: https://movie.douban.com/subject/10533913/
director: '彼特·道格特'
rating: 8.8
year: 2015-10-06(中国大陆)
genre: 喜剧
banner_icon: 🎞
banner: "https://img9.doubanio.com/view/photo/1/public/p2266293606.webp"
status: 看完
progress: 
banner_y: 0.54
---

[[震撼我的电影|电影清单]]

---

# 头脑特工队 Inside Out

**[2015-10-06(中国大陆)] | [ 95分钟 ]** 

可爱的小女孩莱莉（凯特林·迪亚斯 Kaitlyn Dias 配音）出生在明尼苏达州一个平凡的家庭中，从小她在父母的呵护下长大，脑海中保存着无数美好甜蜜的回忆。当然这些记忆还与几个莱莉未曾谋面的伙伴息息相关，他们就是人类的五种主要情绪：乐乐（艾米·波勒 Amy Poehl er 配音）、忧忧（菲利丝·史密斯 Phyllis Smith 配音）、怕怕（比尔·哈德尔 Bill Hader 配音）、厌厌（敏迪·卡灵 Mindy Kaling 配音）和怒怒（刘易斯·布莱克 Lewis Black 配音）。乐乐作为团队的领导，她协同其他伙伴致力于为小主人营造更多美好的珍贵回忆。某天，莱莉随同父母搬到了旧金山，肮脏逼仄的公寓、陌生的校园环境、逐渐失落的友情都让莱莉无所适从，她的负面情绪逐渐累积，内心美好的世界渐次崩塌。

















为了保护这一切，乐乐只有行动起来……

## 观后感

