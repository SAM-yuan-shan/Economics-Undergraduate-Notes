---
name: 阿甘正传 Forrest Gump
cover: https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2372307693.webp
tags: Movie
douban_url: https://movie.douban.com/subject/1292720/
director: '罗伯特·泽米吉斯'
rating: 9.5
year: 1994-06-23(洛杉矶首映)
genre: 剧情
banner_icon: 🎞
banner: "https://img2.doubanio.com/view/photo/1/public/p2372307693.webp"
status: 
progress: 
banner_y: 0.496
---

[[震撼我的电影|电影清单]]

---

# 阿甘正传 Forrest Gump

**[1994-06-23(洛杉矶首映)] | [ 142分钟 ]** 

阿甘（汤姆·汉克斯 饰）于二战结束后不久出生在美国南方阿拉巴马州一个闭塞的小镇，他先天弱智，智商只有75，然而他的妈妈是一个性格坚强的女性，她常常鼓励阿甘“傻人有傻福”，要他自强不息。

















阿甘像普通孩子一样上学，并且认识了一生的朋友和至爱珍妮（罗宾·莱特·潘 饰），在珍妮 和妈妈的爱护下，阿甘凭着上帝赐予的“飞毛腿”开始了一生不停的奔跑。

















阿甘成为橄榄球巨星、越战英雄、乒乓球外交使者、亿万富翁，但是，他始终忘不了珍妮，几次匆匆的相聚和离别，更是加深了阿甘的思念。

















有一天，阿甘收到珍妮的信，他们终于又要见面……

## 观后感

