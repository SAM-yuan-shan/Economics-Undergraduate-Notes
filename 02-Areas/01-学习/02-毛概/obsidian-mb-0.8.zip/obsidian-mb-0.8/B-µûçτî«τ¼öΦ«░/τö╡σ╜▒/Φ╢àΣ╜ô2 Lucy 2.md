---
name: 超体2 Lucy 2
cover: https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2512165972.webp
tags: 动作
douban_url: https://movie.douban.com/subject/26433395/
director: '吕克·贝松'
rating: 9
year: -
genre: 动作
banner_icon: 🎞
banner: "https://img2.doubanio.com/view/photo/1/public/p2512165972.webp"
status: 想看
progress: 
banner_y: 0.372
---

[[震撼我的电影|电影清单]]

---

# 超体2 Lucy 2

**[-] | [ - ]** 

斯嘉丽·约翰逊主演的好莱坞科幻动作大片《超体》在全球引发了史无前例地有关人类大脑开发的热议，超高的票房口碑“迫使”吕克·贝松不得不继续烧脑，与基美影业联手创制了一个当大脑已经开发到了100%之后的故事。

## 观后感

