---
name: 楚门的世界 The Truman Show
cover: https://img2.doubanio.com/view/photo/s_ratio_poster/public/p479682972.webp
tags: 剧情
douban_url: https://movie.douban.com/subject/1292064/
director: '彼得·威尔'
rating: 9.3
year: 1998-06-05(美国)
genre: 剧情
banner_icon: 🎞
banner: "https://img2.doubanio.com/view/photo/1/public/p479682972.webp"
status: 再看
progress: 
banner_y: 0.356
---

[[震撼我的电影|电影清单]]

---

# 楚门的世界 The Truman Show

**[1998-06-05(美国)] | [ 103分钟 ]** 

楚门（金•凯瑞 Jim Carrey 饰）是一个平凡得不能再平凡的人，除了一些有些稀奇的经历之外——初恋女友突然失踪、溺水身亡的父亲忽然似乎又出现在眼前，他和绝大多数30多岁的美国男人绝无异样。这令他倍感失落。他也曾试过离开自己生活了多年的地方，但总因种种理由而不能成行。

















直到有一天，他忽然发觉自己似乎一直在被人跟踪，无论他走到哪里，干什么事情。这种感觉愈来愈强烈。楚门决定不惜一切代价逃离这个他生活了30多年的地方，去寻找他的初恋女友。

















但他却发现自己怎样也逃不出去。真相其实很残忍。

## 观后感

