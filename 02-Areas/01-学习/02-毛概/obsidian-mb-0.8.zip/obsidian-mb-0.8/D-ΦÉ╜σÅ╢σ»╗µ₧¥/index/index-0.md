---
cssClasses: table-numbers, table-tabular, table-nowrap, table-small, table-lines, row-lines, col-lines, row-alt, table-max
banner: "![[africa-gecdb6d7cd_1920.jpg]]"
banner_y: 0.48
banner_icon: 🍋
tags: index
---
- [u]	[[home|返回主页]] | [[index-H | 返回帮助]] |

---

# 图片 

[想要更多好看的页面头图？点我下载](https://pixabay.com/images/search/banner/)

---

```dataview 

table tags,keyword,date
from "0-附件素材" and !#index
sort file.name asc

```
---

- [u] [[#图片|一键回到顶部]]