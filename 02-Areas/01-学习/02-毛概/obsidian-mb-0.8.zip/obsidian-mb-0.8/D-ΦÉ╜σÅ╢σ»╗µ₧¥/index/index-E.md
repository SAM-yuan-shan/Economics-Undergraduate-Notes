---
cssClasses: table-numbers, table-tabular, table-nowrap, table-small, table-lines, row-lines, col-lines, row-alt, table-max
banner: "![[snowdrift-gecf51e07f_1920.jpg]]"
banner_y: 0.364
banner_icon: 🍋
tags: index
---

- [u]	[[home|返回主页]]

---

# E-初稿汇集

```dataview 

table tags,keyword,date
from "E-初稿汇集" and !#index
sort file.name asc

```
---

- [u] [[#E-初稿汇集|一键回到顶部]]