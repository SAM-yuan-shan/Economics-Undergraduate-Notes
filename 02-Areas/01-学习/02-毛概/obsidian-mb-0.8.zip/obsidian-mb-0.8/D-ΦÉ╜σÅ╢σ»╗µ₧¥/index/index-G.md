---
cssClasses: table-numbers, table-tabular, table-nowrap, table-small, table-lines, row-lines, col-lines, row-alt, table-max
banner: "![[alpine-gbdddb9210_1920.jpg]]"
banner_y: 1
banner_icon: 🍋
tags: index
---

- [u]	[[home|返回主页]]

---

# G-发布归档

## 朽木新枝
```dataview 

table tags,keyword,date
from "G-发布归档/朽木新枝" and !#index
sort file.name asc

```
---
## 启发日记
```dataview 

table tags,keyword,date
from "G-发布归档/启发日记" and !#index
sort file.name asc

```
---

- [u] [[#G-发布归档|一键回到顶部]]