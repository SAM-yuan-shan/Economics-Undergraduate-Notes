---
cssClasses: table-numbers, table-tabular, table-nowrap, table-small, table-lines, row-lines, col-lines, row-alt, table-max
banner: "![[brain-g7d2c74ab7_1920.jpg]]"
banner_y: 0.388
banner_icon: 🍋
tags: index
---

- [u]	[[home|返回主页]] | [[关键词漫游|返回找灵感]] | [[index-3| 思维导图]] |

---
  `button-baiban`       `button-mind`    
  
---

# 白板绘图 

```dataview 

table tags,keyword,date
from "2-Excalidraw" and !#index
sort file.name asc

```
---

- [u] [[#白板绘图|一键回到顶部]]