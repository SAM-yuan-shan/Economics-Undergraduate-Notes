---
cssClasses: table-numbers, table-tabular, table-nowrap, table-small, table-lines, row-lines, col-lines, row-alt, table-max
banner: "![[animals-g2ab66e819_1920.jpg]]"
banner_y: 0.706
banner_icon: 🍋
tags: index
banner_x: 0.55782
---

- [u]	[[home|返回主页]] | [[书架上的神明|书架]] | [[震撼我的电影|电影]] |

---

`button-wx`

---

# B-文献笔记

```dataview 

table tags,keyword,date
from "B-文献笔记" and !#index
sort file.name asc

```
---

- [u] [[#B-文献笔记|一键回到顶部]]