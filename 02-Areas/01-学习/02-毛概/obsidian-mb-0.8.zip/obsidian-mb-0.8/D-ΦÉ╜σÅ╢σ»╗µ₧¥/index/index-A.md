---
cssClasses: table-numbers, table-tabular, table-nowrap, table-small, table-lines, row-lines, col-lines, row-alt, table-max
banner: "![[mount-fuji-g707b221b0_1920.jpg]]"
banner_y: 0.428
banner_icon: 🍋
tags: index
---

- [u]	[[home|返回主页]] | [[index-1|日记]] |

---

`button-lingan`   `button-sn` 

---

# A-闪念笔记

```dataview 

table tags,keyword,date
from "A-闪念笔记" and !#index
sort file.name asc

```
---
