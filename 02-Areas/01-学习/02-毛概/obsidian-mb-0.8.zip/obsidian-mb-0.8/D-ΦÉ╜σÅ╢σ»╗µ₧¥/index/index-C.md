---
cssClasses: table-numbers, table-tabular, table-nowrap, table-small, table-lines, row-lines, col-lines, row-alt, table-max
banner: "![[field-g2adb79480_1920.jpg]]"
banner_y: 0.908
banner_icon: 🍋
tags: index
---

- [u]	[[home|返回主页]]

---

`button-zk`

---

# C-永久笔记

```dataview 

table tags,keyword,date
from "C-永久笔记" and !#index
sort file.name asc

```
---
- [u] [[#C-永久笔记|一键回到顶部]]