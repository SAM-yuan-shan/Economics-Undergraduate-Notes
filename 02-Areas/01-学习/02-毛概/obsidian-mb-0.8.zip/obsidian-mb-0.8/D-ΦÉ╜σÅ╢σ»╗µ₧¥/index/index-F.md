---
cssClasses: table-numbers, table-tabular, table-nowrap, table-small, table-lines, row-lines, col-lines, row-alt, table-max
banner: "![[panorama-gdd28ee541_1920.jpg]]"
banner_y: 0.6
banner_icon: 🍋
tags: index
---

- [u]	[[home|返回主页]] | [[index-G|发布归档]] |

---

# F-编辑校对

```dataview 

table tags,keyword,date
from "F-编辑校对" and !#index
sort file.name asc

```
---
- [u] [[#F-编辑校对|一键回到顶部]]