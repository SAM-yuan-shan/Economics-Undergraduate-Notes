---
cssClasses: table-numbers, table-tabular, table-nowrap, table-small, table-lines, row-lines, col-lines, row-alt, table-max
banner: "![[pyramids-g2b942ed19_1920.jpg]]"
banner_y: 0.328
banner_icon: 🍋
tags: index
---

- [u]	[[home|返回主页]]

---

`button-rj`

---

# 日记   



```dataview 

table tags,keyword,date
from "1-日记" and !#index
sort file.name asc

```

---
- [u] [[#日记|一键回到顶部]]