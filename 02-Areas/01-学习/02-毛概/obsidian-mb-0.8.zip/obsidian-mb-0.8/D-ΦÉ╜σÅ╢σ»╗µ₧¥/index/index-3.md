---
banner: "![[brain-g7d2c74ab7_1920.jpg]]"
banner_y: 0.392
banner_icon: 👠
---

- [u]	[[home|返回主页]] | [[index-2| 返回画图思考]]

---


# 思维导图

```query

path: 3-思维导图/xmind/

```
