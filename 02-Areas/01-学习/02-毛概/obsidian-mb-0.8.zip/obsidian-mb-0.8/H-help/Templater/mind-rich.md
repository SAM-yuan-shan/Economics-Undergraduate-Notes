---

mindmap-plugin: rich

---
