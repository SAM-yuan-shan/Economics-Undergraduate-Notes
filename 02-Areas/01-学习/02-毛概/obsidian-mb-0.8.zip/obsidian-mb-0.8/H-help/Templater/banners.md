---
banner: "![[mountains-g8e2992e4d_1920.jpg]]"
banner_y: 0.11839
banner_icon: 👠
---