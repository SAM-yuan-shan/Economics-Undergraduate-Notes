---
name: {{VALUE:fileName}}
cover: {{VALUE:Poster}}
tags: {{VALUE:genre}}
douban_url: {{VALUE:douban_url}}
director: {{VALUE:director}}
rating: {{VALUE:rating}}
year: {{VALUE:year}}
genre: {{VALUE:genre}}
banner_icon: 🎞
banner: "{{VALUE:banner}}"
status: 想看
progress: 
---

[[震撼我的电影|电影清单]]

---

# {{VALUE:fileName}}

**[{{VALUE:year}}] | [ {{VALUE:runtime}} ]** 

{{VALUE:plot}}

## 观后感

