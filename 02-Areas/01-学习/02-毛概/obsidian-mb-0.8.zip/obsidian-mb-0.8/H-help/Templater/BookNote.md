---
tags: {{VALUE:tags}}
from: 文献笔记
status: 想读
granularity: 
ISBN: {{VALUE:isbn}}
title: {{VALUE:name}}
出版发行: {{VALUE:publisher}}
aliases: 
keyword: 
category: 
author: {{VALUE:author}}
transAuthor: {{VALUE:transAuthor}}
rating: {{VALUE:rating}}
link: {{VALUE:link}}
cover:  {{VALUE:coverUrl}}
pages: {{VALUE:pages}}
BeginDate: {{DATE}}
EndDate:
pageprogress:
banner: "{{VALUE:coverUrl}}"
banner_y: 0.30239
banner_icon: 📚
---

```
= this.file.tags
```

现在是 `=date(now)`，距离第一次看《{{VALUE:name}}》已经过去了==`=(date(today)-this.BeginDate).days`==天。

此刻有什么新[[#想法]]呢？

[[书架上的神明|查看完整书单]]

---
# 作者简介

> [!note]- 作者简介\
> {{VALUE:authorIntro}}
>
>

# 想法

内容