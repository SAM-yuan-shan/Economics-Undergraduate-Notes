---
cover: 
date: <% tp.file.creation_date() %>
tags: 
from: 文献笔记
status: 
granularity: 
ISBN: 
title: 
出版发行: 
Summary: 
aliases: 
keyword: 
category: 
author: 
banner: "![[mountains-g8e2992e4d_1920.jpg]]"
banner_y: 0.59839
banner_icon: 📚
---

```
= this.file.tags
```


[[index-C|返回目录]]

---

内容

---  
## 相关链接