---
date: <% tp.file.creation_date() %>
tags: 
keyword: 
aliases: 
author: 朽木新枝
from: 永久笔记 
banner: "![[flamingo-ga87497c9f_1920.jpg]]"
banner_y: 0.50639
banner_icon: 🗃️
---

```
= this.file.tags
```

[[index-C|返回目录]]

---

内容

---  
## 相关链接