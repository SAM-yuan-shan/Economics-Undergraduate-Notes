# 新建笔记


```button
name 记录灵感
type command
action QuickAdd: 灵光
color purple
```
^button-lingan

---

```button
name 新建白板绘图
type command
action Excalidraw: 新建绘图（在当前面板）
color blue
```
^button-baiban

---

```button
name 新建闪念笔记
type command
action QuickAdd: 新建闪念笔记
color green
```
^button-sn

---
```button
name 新建永久笔记
type command
action QuickAdd: 新建永久笔记
color purple
```
^button-zk

---

```button
name 写日记
type command
action 日记: 打开/创建今天的日记
color blue
```
^button-rj

---

```button
name 新建文献笔记
type command
action QuickAdd: 新建文献笔记
color red
```
^button-wx

---

```button
name 新建书影笔记
type command
action QuickAdd: 书影笔记生成
color yellow
```
^button-shuying

---
```button
name 新建思维导图
type command
action QuickAdd: 思维导图
color red
```
^button-mind

---

# 系统功能快捷按键

---

```button
name 备忘录
type command
action Obsidian Memos: Open Memos
color yellow
```
^button-memos

---

```button
name 文件恢复
type command
action 文件恢复: 打开快照列表
color red
```
^button-huifu

---

```button
name 关灯
type command
action 使用黑暗模式
color Default Color
```
^button-heian

---

```button
name 开灯
type command
action 使用明亮模式
color purple
```
^button-mingliang

---


```button
name B 站
type link
action https://t.bilibili.com/?spm_id_from=333.999.b_696e7465726e6174696f6e616c486561646572.29
color blue
```
^button-bzz

---

```button
name 知识图谱
type command
action 关系图谱: 查看关系图谱
color red
```
^button-tu

---